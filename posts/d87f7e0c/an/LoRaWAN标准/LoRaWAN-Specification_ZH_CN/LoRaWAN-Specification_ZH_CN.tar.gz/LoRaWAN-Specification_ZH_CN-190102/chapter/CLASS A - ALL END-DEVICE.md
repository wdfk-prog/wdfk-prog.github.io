
# CLASS A - ALL END-DEVICE

所有的LoRaWAN终端都必须满足Class A的规定。
