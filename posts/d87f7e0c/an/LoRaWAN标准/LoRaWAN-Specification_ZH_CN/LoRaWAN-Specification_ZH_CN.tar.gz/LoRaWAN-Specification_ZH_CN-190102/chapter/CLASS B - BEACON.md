
# CLASS B – BEACON

Class B在当前协议版本中还仅作实验性参考。
